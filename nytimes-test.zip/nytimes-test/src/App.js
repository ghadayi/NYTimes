import React, { Component } from "react";

import Toolbar from "./components/Toolbar/Toolbar";
import SideDrawer from "./components/SideDrawer/SideDrawer";
import Backdrop from "./components/Backdrop/Backdrop";
import FetchAPI from "./components/fetchAPI";
import IFrame from "./components/IFrame";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { browserHistory } from "react-router";

class App extends Component {
  state = {
    sideDrawerOpen: false,
    loading: true
  };

  drawerToggleClickHandler = () => {
    this.setState(prevState => {
      return { sideDrawerOpen: !prevState.sideDrawerOpen };
    });
  };

  backdropClickHandler = () => {
    this.setState({ sideDrawerOpen: false });
  };

  render() {
    let backdrop;
    if (this.state.sideDrawerOpen) {
      backdrop = <Backdrop click={this.backdropClickHandler} />;
    }
    return (
      <div style={{ height: "100%" }}>
        <Toolbar drawerClickHandler={this.drawerToggleClickHandler} />
        <SideDrawer show={this.state.sideDrawerOpen} />
        {backdrop}
        <main style={{ marginTop: "64px" }}>
          {/* <FetchAPI show={this.state.loading} /> */}
          <Router history={browserHistory}>
            <Route>
              <Switch>
                <Route path="/" components={App}>
                  <Route
                    path="/IFrame"
                    show={this.state.loading}
                    component={IFrame}
                  />
                  <Route path="/FetchAPI" component={FetchAPI} />
                  <Route exact path="/" component={FetchAPI} />
                </Route>
              </Switch>
            </Route>
          </Router>
        </main>
      </div>
    );
  }
}

export default App;
