import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Image from "react-bootstrap/Image";
import { Link } from "react-router-dom";

const Table = ({ nytimesData }) => {
  return (
    <div id="ContainerRoot">
      <table className="table">
        <tbody>
          {nytimesData.length > 0 ? (
            nytimesData.map((nytimesData, index) => {
              return (
                <tr key={index}>
                  <td style={{ width: 120 }}>
                    <Image
                      class="img-responsive"
                      alt="image"
                      src={nytimesData.media[0]["media-metadata"][0].url}
                      roundedCircle
                      thumbnail
                      fluid
                    />
                  </td>
                  <td>
                    <h3>
                      <Link
                        style={{ color: "black" }}
                        to={{
                          pathname: "/IFrame"
                        }}
                      >
                        {" "}
                        {nytimesData.title}
                      </Link>
                      {localStorage.clear()}
                      {localStorage.setItem("myData", nytimesData.url)}

                      <Link
                        style={{ float: "right" }}
                        to={{
                          pathname: "/IFrame"
                        }}
                      >
                        <Image
                          style={{ width: 20 }}
                          src="https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_navigate_next_48px-512.png"
                        />{" "}
                      </Link>
                    </h3>
                    <p>
                      {nytimesData.byline}
                      <br />
                      {nytimesData.source}{" "}
                      <span style={{ float: "right" }}>
                        {nytimesData.published_date}
                      </span>
                    </p>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan="5">Loading...</td>
            </tr>
          )}
        </tbody>
      </table>
      {/* <IFrame PageUrl={nytimesData} /> */}
    </div>
  );
};

export default Table;
