import React, { Component } from "react";
import Table from "../components/Table.jsx";

class NytimesAPI extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nytimesData: [],
      loading: true
    };
  }
  async componentDidMount() {
    const url =
      "https://api.nytimes.com/svc/mostpopular/v2/viewed/30.json?api-key=sfdSSCRJxILbK3H2UYpwnoLDGSC1B8Wc";
    const response = await fetch(url);
    const data = await response.json();
    this.setState({ nytimesData: data.results, loading: false });
  }

  render() {
    if (this.state.loading) {
      return <div>loading..</div>;
    }
    if (!this.state.nytimesData) {
      return <div>No Data</div>;
    }
    return <Table nytimesData={this.state.nytimesData} />;
  }
}

export default NytimesAPI;
