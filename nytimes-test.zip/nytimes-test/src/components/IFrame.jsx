import React, { Component } from "react";
import { render } from "react-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import IframeResizer from "react-iframe-resizer-super";

const iframeResizerOptions = {
  log: true,
  // autoResize: true,
  checkOrigin: false
  // resizeFrom: 'parent',
  // heightCalculationMethod: 'max',
  // initCallback: () => { console.log('ready!'); },
  // resizedCallback: () => { console.log('resized!');
};

class IFrame extends Component {
  render() {
    console.log(localStorage.getItem("myData"));
    return (
      <div style={{ position: "relative" }}>
        {" "}
        <IframeResizer
          src={localStorage.getItem("myData")}
          iframeResizerOptions={iframeResizerOptions}
          style={{
            height: "-webkit-fill-available",
            width: "-webkit-fill-available"
          }}
        />
      </div>
    );
  }
}
render(<IFrame />, window.document.getElementById("root"));

export default IFrame;
