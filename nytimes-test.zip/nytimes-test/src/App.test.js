import { shallow } from "enzyme";
import IFrame from "./components/IFrame";
it("renders welcome message", () => {
  <script src="node_modules/react-dom/cjs/react-dom.development.js" />;
  const wrapper = shallow(<FetchAPI show={false} />);
  const loading = "loading";
  expect(wrapper.contains(loading)).toEqual(true);
});
